# ----------------------------------------
grid = [[1, 1, 1, 0, 0, 0],
        [1, 1, 1, 0, 1, 0],
        [0, 0, 0, 0, 0, 0], 
        [1, 1, 1, 0, 1, 1],
        [1, 1, 1, 0, 1, 1]] # this is the same as image grid
init = [4, 3, 0] # starting position,first 2 elements are coordinates,third is direction
goal = [2, 0] # goal position
delta = [[-1, 0], # go up
         [ 0,-1], # go left
         [ 1, 0], # go down
         [ 0, 1]] # do right
cost = [2, 1, 20] #the cost field has 3 values: right turn, no turn, left turn
action = [-1, 0, 1] #right turn, straight, left turn
action_name = ['R', '#', 'L']

## ----------------------------------------
def optimum_policy():
    value = [[[999 for row in range(len(grid[0]))] for col in range(len(grid))],
             [[999 for row in range(len(grid[0]))] for col in range(len(grid))],
             [[999 for row in range(len(grid[0]))] for col in range(len(grid))],
             [[999 for row in range(len(grid[0]))] for col in range(len(grid))]]

    policy = [[[' ' for row in range(len(grid[0]))] for col in range(len(grid))],
              [[' ' for row in range(len(grid[0]))] for col in range(len(grid))],
              [[' ' for row in range(len(grid[0]))] for col in range(len(grid))],
              [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]]
    policy2D = [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]
    change = True
    while change:
        change = False
        for x in range(len(grid)):
            for y in range(len(grid[0])):
                for k in range(4): # k is orientation
                    if goal[0] == x and goal[1] == y:
                       if value[k][x][y] > 0:
                          value[k][x][y] = 0
                          policy[k][x][y] = '*'
                          change = True
                    elif grid[x][y] == 0:
                         for i in range(3):
                             k2 = k + action[i] #steers
                             for k2 in range(len(delta)):
                                 x2 = x + delta[k2][0] #then moves
                                 y2 = y + delta[k2][1] #then moves
                                 if x2 >= 0 and x2 < len(grid) and y2 >=0 and y2< len(grid[0]) and grid[x2][y2] == 0:
                                    v2 = value[k2][x2][y2] + cost[i]
                                    if v2 < value[k][x][y]:
                                       change = True
                                       value[k][x][y] = v2
                                       policy[k][x][y] = action_name[i]
    x = init[0]
    y = init[1]
    k = init[2]
    policy2D[x][y] = policy[k][x][y]
    while policy[k][x][y] != '*':
          if policy[k][x][y] == '#':
             k2 = k
          if policy[k][x][y] == 'R':
             k2 = k - 1
          if policy[k][x][y] == 'L':
             k2 = k + 1
          for k2 in range(len(delta)):
              x = x + delta[k2][0]
              y = y + delta[k2][1]
              k = k2
              policy2D[x][y] = policy[k][x][y]
    print policy2D
optimum_policy()
### ----------------------------------------

