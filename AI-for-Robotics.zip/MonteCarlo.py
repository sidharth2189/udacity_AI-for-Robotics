##---------------Variables-----------------------------
##p = [0.2, 0.2, 0.2, 0.2, 0.2] # max confusion probability distribution
p = [0, 1, 0, 0, 0] # max confusion probability distribution
world = ['green', 'red', 'red', 'green', 'green']
measurement = ['red', 'green'] # sensor measurement
pHit = 0.6 # likelihood of matching measurment
pMiss = 0.2

##---------------InExact-Motion-probabilities----------
# Add exact probability
pExact = 0.8
# Add overshoot probability
pOvershoot = 0.1
# Add undershoot probability
pUndershoot = 0.1

##---------------Sense-Function------------------------
def sense(p, z):
    q = [ ]
    for i in range(len(p)):
        if z == world[i]:
           q.append(p[i] * pHit)
        else:
           q.append(p[i] * pMiss)
    s = sum(q)
    for i in range (len(p)):
        q[i] = q[i]/s
    return q

##---------------Move-Function-------------------------
def move(p, u):
    d = []
    for i in range(len(p)):        
        s1 = pExact*p[(i-u)%len(p)]
        s2 = pOvershoot*p[(i-u-1)%len(p)]
        s3 = pUndershoot*p[(i-u+1)%len(p)]
        s = s1 + s2 + s3
        d.append(s)
    return d
            
##---------------Call-Functions------------------------
p = sense(p,measurement[0])
##p = move(p,1)
##p = move(p,1) # Move twice
##for k in range(1000): # Move 1000 times
##    p = move(p,1)
##print p
## Uniform distribution as result of "print p" means after 1000 moves, all information about the robot's location is lost.
## There is need to continuously sense to keep track of the robot's location.

p = move(p,1)
print p
p = sense(p, measurement[0])
p = move(p,1)
print p
# answer to above print p is cell 4 has highest probability of 0.7
# sensing and moving is essentially monte carlo localization approach used in google's self-driving car

##--------- Monte-Carlo-Localization-Steps-------------
#1 start with belief set about current location
#2 Multiply this distribution by the results of our sense measurement
#3 Normalize the resulting distribution
#4 Move by performing a convolution, which means multiply/add to obtain new probabilities at each location
#Remark: Step #2 increases information and step #4 decreses information about location
