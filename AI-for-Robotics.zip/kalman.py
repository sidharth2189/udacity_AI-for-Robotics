import numpy as np
from math import *
measurements = [1, 2, 3]
x = np.matrix([[0], [0]]) # initial state (location and velocity)
p = np.matrix([[1000, 0], [0, 1000]]) # initial uncertainity co-variance
u = np.matrix([[0], [0]]) # external motion/motion vector
f = np.matrix([[1, 1], [0, 1]]) # state transition matrix
h = np.matrix([[1, 0]]) # measurement function
r = np.matrix([[1]]) # measurement uncertainity/noise
I = np.matrix([[1, 0], [0, 1]]) # identity matrix

def filter(x, p, measurements, u, f, h, r, I):
    for n in range(len(measurements)):
        # measurement update
        y = measurements[n] - h*x
        s = h*p*h.transpose() + r
        k = p*h.transpose()*s**(-1)
        x = x + k*y
        p = (I - (k*h)) * p
        # prediction
        x = f*x + u
        p = f*p*f.transpose()
        print 'x= ', x
        print 'p= ',p
filter(x, p, measurements, u, f, h, r, I)

