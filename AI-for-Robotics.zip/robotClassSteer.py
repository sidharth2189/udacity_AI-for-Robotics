from math import *
import random
import matplotlib.pyplot as plt

class robot:
    def __init__(self, length = 20):
        self.x = 0
        self.y = 0
        self.length = length
        self.orientation = 0
        self.steering_noise = 0;
        self.distance_noise = 0;
        self.steering_drift = 0;

    def set(self, new_x, new_y, new_orientation):
        self.x = float(new_x)
        self.y = float(new_y)
        self.orienatation = float(new_orientation) %(2*pi)

    def set_noise(self, new_s_noise, new_d_noise):
        # makes it possible to change noise parameters
        # often useful in particle filters
        self.steering_noise = float(new_s_noise)
        self.distance_noise = float(new_d_noise)

    def set_steering_drift(self, drift):
        self.steering_drift = drift

    def move(self, steering, distance, tolerance = 0.001, max_steering_angle = pi/4):

        if steering > max_steering_angle:
            steering = max_steering_angle
        if steering < -max_steering_angle:
            steering = -max_steering_angle
        if distance < 0:
            distance = 0

        # make a new copy
        res = robot()
        res.length = self.length
        res.steering_noise = self.steering_noise
        res.distance_noise = self.distance_noise
        res.steering_drift = self.steering_drift

        # apply noise
        steering2 = random.gauss(steering, self.steering_noise)
        distance2 = random.gauss(distance, self.distance_noise)

        # apply steering drift
        steering2 = steering2 + self.steering_drift

        # execute motion
        turn = tan(steering2) * distance2 / res.length

        if abs(turn) < tolerance:
            # approximate by straight line motion
            res.x = self.x + (distance2 * cos(self.orientation))
            res.y = self.y + (distance2 * sin(self.orientation))
            res.orientation = (self.orientation + turn) % (2 * pi)
        else:
            # approximate bicycle model for motion
            radius = distance2 / turn
            cx = self.x - (sin(self.orientation) * radius)
            cy = self.y + (cos(self.orientation) * radius)
            res.orientation = (self.orientation + turn) % (2 * pi)
            res.x = cx + (sin(res.orientation) * radius)
            res.y = cy - (cos(res.orientation) * radius)

        return res

    def __repr__(self):
        return '[x = %.5f y = %.5f orient = %.5f]' % (self.x, self.y, self.orientation)

## --------P controller----------------------------------------
##def runP(param):
##    myrobot = robot()
##    myrobot.set(0, 1, 0)
##    speed = 1
##    N = 100
##    x1 = []
##    x2 = []
##    for i in range(N):
##        crosstrack_error = myrobot.y
##        steer = -param * crosstrack_error
##        myrobot = myrobot.move(steer, speed)
##        print myrobot, steer
##        x1.append(myrobot.x)
##        x2.append(crosstrack_error)
##    return x1,x2
##
##y_P = runP(0.05)
##plt.plot(y_P[1])
##plt.show()

#### --------PD controller----------------------------------------
##def runPD(param1, param2):
##    myrobot = robot()
##    myrobot.set(0, 1, 0)
##    speed = 1
##    N = 100
##    x1 = []
##    x2 = []
##    crosstrack_error = []
##    for i in range(N):
##        crosstrack_error.append(myrobot.y)
##        if i == 0:
##            steer = -param1 * crosstrack_error[0]
##        else:
##            steer = -param1 * crosstrack_error[i] - param2 * (crosstrack_error[i] - crosstrack_error[i-1])
##        myrobot = myrobot.move(steer, speed)
##        print myrobot, steer
##        x1.append(myrobot.x)
##        x2.append(myrobot.y)
##    return x1,x2
##
##y_PD = runPD(0.2, 0)
##plt.plot(y_PD[1])
##plt.ylabel('Cross Track Error')
##plt.show()

## --------PID controller----------------------------------------
def runPD(param1, param2, param3):
    myrobot = robot()
    myrobot.set(0, 1, 0)
    speed = 1
    N = 100
    x1 = []
    x2 = []
    crosstrack_error = []
    int_crosstrack_error = 0
    for i in range(N):
        crosstrack_error.append(myrobot.y)
        int_crosstrack_error = int_crosstrack_error + crosstrack_error[i]
        if i == 0:
            steer = -param1 * crosstrack_error[0]
        else:
            steer = -param1 * crosstrack_error[i] - param2 * (crosstrack_error[i] - crosstrack_error[i-1]) - param3 * int_crosstrack_error
        myrobot = myrobot.move(steer, speed)
        myrobot.set_steering_drift(10 / 180 * pi) # sets steering error to 10 degrees
        print myrobot, steer
        x1.append(myrobot.x)
        x2.append(myrobot.y)
    return x2

y_PD = runPD(0.5, 4, 0.03)
##plt.plot(y_PD)
##plt.ylabel('Cross Track Error')
##plt.show()
