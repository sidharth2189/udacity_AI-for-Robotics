# ----------------------------------------
##grid = [[0, 1, 0, 0, 0, 0],
##        [0, 1, 0, 0, 0, 0],
##        [0, 1, 0, 0, 0, 0],
##        [0, 1, 0, 0, 0, 0],
##        [0, 0, 0, 0, 1, 0]] # this is the same as image grid
grid = [[0, 0, 1, 0, 0, 0],
        [0, 0, 1, 0, 0, 0],
        [0, 0, 1, 0, 0, 0],
        [0, 0, 0, 0, 1, 0],
        [0, 0, 1, 1, 1, 0],
        [0, 0, 0, 0, 1, 0]] # this is the same as image grid
init = [0, 0] # starting position
goal = [len(grid)-1, len(grid[0])-1] # goal position
delta = [[-1, 0], # go up
         [0, -1], # go left
         [1, 0], # go down
         [0, 1]] # do right
delta_name = ['<', '^', 'v', '>']

cost = 1 # each move costs 1

## ----------------------------------------
def compute_value():
    value = [[99 for row in range(len(grid[0]))] for col in range(len(grid))]
    policy = [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]
    change = True
    while change:
        change = False
        for x in range(len(grid)):
            for y in range(len(grid[0])):
                if goal[0] == x and goal[1] == y:
                   if value[x][y] > 0:
                       value[x][y] = 0
                       policy[x][y] = '*'
                       change = True
                elif grid[x][y] == 0:
                    for i in range(len(delta)):
                        x2 = x + delta[i][0]
                        y2 = y + delta[i][1]
                        if x2 >= 0 and x2 < len(grid) and y2 >=0 and y2< len(grid[0]):
                            v2 = value[x2][y2] + cost
                            if v2 < value[x][y]:
                                change = True
                                value[x][y] = v2
                                if y > y2:
                                   policy[x][y] = delta_name[0]
                                if y < y2:
                                   policy[x][y] = delta_name[3]
                                if x < x2:
                                   policy[x][y] = delta_name[2]
                                if x > x2:
                                   policy[x][y] = delta_name[1]
    print value
    print policy
compute_value()
### ----------------------------------------

