from math import *
import random

landmarks = [[20, 20],
             [80, 80],
             [20, 80],
             [80, 20]]
world_size = 100

class robot:
    def __init__(self):
        self.x = random.random() * world_size
        self.y = random.random() * world_size
        self.orientation = random.random() * 2 * pi
        self.forward_noise = 0;
        self.turn_noise    = 0;
        self.sense_noise   = 0;

    def set(self, new_x, new_y, new_orientation):
        if new_x < 0 or new_x >= world_size:
            raise ValueError, 'X co-ordinate out of bound'
        if new_y < 0 or new_y >= world_size:
            raise ValueError, 'Y co-ordinate out of bound'
        if new_orientation < 0 or new_orientation >= 2 * pi:
            raise ValueError, 'Orientation must be in [0, 2pi]'
        self.x = float(new_x)
        self.y = float(new_y)
        self.orienatation = float(new_orientation)

    def set_noise(self, new_f_noise, new_t_noise, new_s_noise):
        # makes it possible to change noise parameters
        # often useful in particle filters
        self.forward_noise = float(new_f_noise)
        self.turn_noise = float(new_t_noise)
        self.sense_noise = float(new_s_noise)

    def sense(self):
        z = []
        for i in range(len(landmarks)):
            dist = sqrt((self.x - landmarks[i][0]) ** 2 + (self.y - landmarks[i][1]) ** 2)
            dist = dist + random.gauss(0, self.sense_noise)
            z.append(dist)
        return z

    def move(self, turn, forward):
        if forward < 0:
           raise ValueError, 'Robot cant move backwards'
        # turn and add randomness to the turning command
        orientation = self.orientation + float(turn) + random.gauss(0, self.turn_noise)
        orientation = orientation % 2 * pi

        # move and add randomness to motion command
        dist = float(forward) + random.gauss(0, self.forward_noise)
        x = self.x + (cos(orientation)* dist)
        y = self.y + (sin(orientation)* dist)
        x = x % world_size
        y = y % world_size

        # set particle
        res = robot()
        res.set(x,y,orientation)
        res.set_noise(self.forward_noise, self.turn_noise, self.sense_noise)
        return res

    def Gaussian(self, mu, sigma, x):

        # calculates the probability of x for 1-dim gaussian with mean mu and var. sigma
        return exp(-((mu-x) ** 2) / (sigma ** 2) / 2) / sqrt(2 * pi * (sigma ** 2))
                        
    def measurement_prob(self, measurement):
        # calculates how likely a measurement should be, an essential step
        prob = 1
        for i in range(len(landmarks)):
            dist = sqrt((self.x - landmarks[i][0]) ** 2 + (self.y - landmarks[i][1]) ** 2)
            prob = prob * self.Gaussian(dist, self.sense_noise, measurement[i])
        return prob

    def __repr__(self):
        return '[x = %.6s y = %.6s orient = %.6s]' % (str(self.x), str(self.y), str(self.orientation))

def eval(r, p):
    sume = 0
    for i in range(len(p)): # calculate mean error
        dx = (p[i].x - r.x + (world_size/2)) % world_size - (world_size/2)
        dy = (p[i].y - r.y + (world_size/2)) % world_size - (world_size/2)
        err = sqrt(dx * dx + dy * dy)
        sume = sume + err
    return sume / float(len(p))
# ----------------------------------------------------------

##myrobot = robot()
##myrobot.set(30, 50, 3.14/2) # x, y and orientation in radians
##myrobot = myrobot.move(-pi/2, 15)
##print myrobot.sense()
##myrobot = myrobot.move(-pi/2, 10)
##print myrobot.sense()

##myrobot = robot() # this is a random initialization of the robot, which will return a random output
##myrobot = myrobot.move(0.1, 5.0)
##z = myrobot.sense()
##print z
##print myrobot

### select 1000 particles
##N = 1000
##p = []
##for i in range(N):
##    x = robot()
##    x.set_noise(0.05, 0.05, 5)
##    p.append(x)
##
### weights of the 1000 particles
##w = []
##for i in range(N):
##    w.append(p[i].measurement_prob(z))
##print w
##
### sample 1000 particles


## ------------------------------------------------------------------
N = 1000 # Random location guess
T = 10
myrobot = robot()

p = []
for i in range(N):
    r = robot()
    #r.set_noise(0.01, 0.01, 1)
    r.set_noise(0.05, 0.05, 5)
    p.append(r)

for t in range(T):
    z = myrobot.sense()
                         
    p2 = []
    for i in range(N):
        p2.append(p[i].move(0.1, 5.0))
    p = p2
                         
    w = []
    for i in range(N):
        w.append(p[i].measurement_prob(z))

    p3 = []
    index = int(random.random() * N)
    beta = 0
    mw = max(w)
    for i in range(N):
        beta = beta + random.random() * 2 * mw
        while beta > w[index]:
             beta = beta - w[index]
             index = (index + 1) % N
        p3.append(p[index])
    p = p3
    
    # print p                         
    print eval(myrobot, p)
                             
if eval(myrobot, p) > 15:
   for i in range(N):
       print '#', i, p[i]
   print 'R', myrobot
## ------------------------------------------------------------
