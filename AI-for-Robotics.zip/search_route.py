# ----------------------------------------
grid = [[0, 0, 1, 0, 0, 0],
        [0, 0, 1, 0, 1, 0],
        [0, 0, 1, 0, 1, 0],
        [0, 0, 1, 0, 1, 0],
        [0, 0, 0, 0, 1, 0]] # this is the same as image grid
init = [0, 0] # starting position
goal = [len(grid)-1, len(grid[0])-1] # goal position
delta = [[-1, 0], # go up
         [0, -1], # go left
         [1, 0], # go down
         [0, 1]] # do right
delta_name = ['<', '^', 'v', '>']

cost = 1 # each move costs 1

# ----------------------------------------
def search():
    closed = [[0 for row in range(len(grid[0]))] for col in range(len(grid))]
    closed[init[0]][init[1]] = 1
    action = [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]
    x = init[0]
    y = init[1]
    g = 0
    open = [[g,x,y]]
    found = False  # flag that is set when search is complete
    resign = False # flag that is set if cell cannot expand

    while not found and not resign:
           if len(open) == 0:
               resign = True
               print ("fail")
           else:
               open.sort()
               next = open.pop(0)
               x = next[1]
               y = next[2]
               g = next[0]
               if x == goal[0] and y == goal[1]:
                   found = True
               else:
                   for i in range(len(delta)):
                       x2 = x + delta[i][0]
                       y2 = y + delta[i][1]
                       if x2 >= 0 and x2 < len(grid) and y2>=0 and y2 < len(grid[0]):
                           if closed[x2][y2] == 0 and grid[x2][y2] == 0:
                               g2 = g + cost
                               open.append([g2, x2, y2])
                               closed[x2][y2] = 1
                               action[x2][y2] = i
##                               if y2 > y:
##                                   route[x][y] = delta_name[3]
##                               if y2 < y:
##                                   route[x][y] = delta_name[0]
##                               if x2 < x:
##                                   route[x][y] = delta_name[1]
##                               if x2 > x:
##                                   route[x][y] = delta_name[2]
##                               if x2 == goal[0] and y2 == goal[1]:
##                                   route[x2][y2] = '*'
                               
    print next
####  Backtrack    
    policy = [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]
    x = goal[0]
    y = goal[1]
    policy[x][y] = '*'
    while x != init[0] or y !=init[1]:
        x3 = x - delta[action[x][y]][0]
        y3 = y - delta[action[x][y]][1]
##        policy[x3][y3] = delta_name[action[x][y]] ## only if order is delta_name = ['^', '<', 'v', '>']
        if y > y3:
            policy[x3][y3] = delta_name[3]
        if y < y3:
            policy[x3][y3] = delta_name[0]
        if x < x3:
            policy[x3][y3] = delta_name[1]
        if x > x3:
            policy[x3][y3] = delta_name[2]
        x = x3
        y = y3

    print policy
##    print action
# ----------------------------------------
search()
